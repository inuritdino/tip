function OUT=brusseq(t,X)
%DUFFING   Brusselator equation 
%          (a 2nd-order continuous autonomous system):
%
%          dx/dt = a + x^2*y - b*x - x
%          dy/dt = b*x - x^2*y
%

%Parameters
A=1.0;
B=3.0;

%Rearrange input data in desired format
%Note: the input data is a column vector
x=X(1); y=X(2);
Q=[X(3),X(5);
   X(4),X(6)];

%Duffing's equation
dx=A + x^2*y - B*x - x;
dy=B*x - x^2*y;

DX1=[dx;dy];	%Output data

%Linearized system
J=[    2*x*y-B-1,   x^2;
   B-2*x*y,  -x^2];

%Variational equation
F=J*Q;

%Put output data in a column vector
OUT=[DX1;F(:)];

