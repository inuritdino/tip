function OUT=harmonicfriceq(t,X)
%HARMONICEQ  Harmonic oscillator with friction equation 
%
%               dx/dt = y
%               dy/dt = -(k/m)*x - (b/m)*y
%


%PARAMETERS
K = 1.0;
M = 1.0;
B = 0.4;

%Rearrange input data in desired format
%Note: the input data is a column vector
x=X(1);y=X(2);
Q=[X(3), X(5);
   X(4), X(6)];


%Lorenz equation
dx=y;
dy=-(K/M)*x -(B/M)*y;

DX1=[dx;dy;];	%Output data

%Linearized system
 J=[0,      1.0;
    -(K/M), -(B/M)];
  
%Variational equation   
F=J*Q;

%Output data must be a column vector
OUT=[DX1; F(:)];

