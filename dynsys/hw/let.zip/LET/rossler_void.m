function OUT=rossler_void(t,X)
%ROSSLER  Rossler equation 
%  In this demo, a = 0.15, b = 0.20, c = 10.0
%  Initial conditions: x(0) = 1, y(0) = 1, z(0) = 1
%  Reference values: LE1 = 0.09, LE2 = 0.00, LE3 = -9.77, LD = 2.01

%Parmaters:
a = ??;
b = ??;
c = ??;

%Rearrange input data in desired format
%Note: the input data is a column vector
x=X(1); y=X(2); z=X(3);
Q =[X(4), X(7), X(10);
    X(5), X(8), X(11);
    X(6), X(9), X(12)];
 
%Rossler equation
dx = ??;
dy = ??;
dz = ??;

DX=[dx; dy; dz]; %Output data

%Linearized system
J=[??, ??, ??;
   ??, ??, ??;
   ??, ??, ??];

%Variational equation
F=J*Q;

%Output data must be a column vector
OUT=[DX(:); F(:)];

